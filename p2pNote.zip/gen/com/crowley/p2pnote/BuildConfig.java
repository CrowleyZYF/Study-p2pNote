/** Automatically generated file. DO NOT MODIFY */
package com.crowley.p2pnote;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}